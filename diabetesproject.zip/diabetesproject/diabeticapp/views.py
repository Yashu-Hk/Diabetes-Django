from django.shortcuts import render
from django.urls import path
from django.http import HttpResponse
import pandas as pd
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
# Create your views here.

def index(request):
    return render(request,"index.html")

def predict(request):
    return render(request,"predict.html")

def result(request):
    data=pd.read_csv('diabetes.csv')
    x=data.drop(['DiabetesPedigreeFunction','Age','Outcome'],axis=1)  #[['Pregnancies','Glucose','BloodPressure','SkinThickness','Insulin']]
    y=data.Outcome
    model=LogisticRegression()
    model.fit(x,y)
    val1=float(request.GET['glucose'])
    val2=float(request.GET['blood-pressure'])
    val3=float(request.GET['skin-thickness'])
    val4=float(request.GET['insulin'])
    val5=float(request.GET['bmi'])
    val6=float(request.GET['pregnancies'])
    pred=model.predict([[val1,val2,val3,val4,val5,val6]])
    result=""
    if pred == [0]:
        result="<h1>You are not Diabetic.</h1>"
    else:
        result="<h1>You are Diabetic.</h1>"

    return HttpResponse(result)